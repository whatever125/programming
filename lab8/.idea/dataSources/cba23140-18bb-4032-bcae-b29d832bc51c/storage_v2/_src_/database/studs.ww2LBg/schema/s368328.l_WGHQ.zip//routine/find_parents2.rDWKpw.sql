create function find_parents2(name_param character varying, surname_param character varying)
    returns TABLE(parent_name character varying, parent_surname character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT parent.name, parent.surname FROM person parent
        INNER JOIN parents ON (parent.id = parents.parent1_id OR parent.id = parents.parent2_id)
        INNER JOIN person child ON child.id = parents.child_id
        WHERE child.name = name_param
            AND child.surname = surname_param;
END;
$$;

alter function find_parents2(varchar, varchar) owner to s368328;

