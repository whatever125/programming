create function trigger_find_parents() returns trigger
    language plpgsql
as
$$
BEGIN
    PERFORM find_parents(NEW.name, NEW.surname);
    RETURN NEW;
END;
$$;

alter function trigger_find_parents() owner to s368328;

