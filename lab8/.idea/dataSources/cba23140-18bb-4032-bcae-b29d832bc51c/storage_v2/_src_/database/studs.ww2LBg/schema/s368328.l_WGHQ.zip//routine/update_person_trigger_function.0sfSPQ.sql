create function update_person_trigger_function() returns trigger
    language plpgsql
as
$$
BEGIN
    PERFORM print_find_parents(NEW.name, NEW.surname);
    RETURN NEW;
END;
$$;

alter function update_person_trigger_function() owner to s368328;

