create function print_find_parents(name_param character varying, surname_param character varying) returns void
    language plpgsql
as
$$
DECLARE
    result RECORD;
BEGIN
    RAISE NOTICE 'Имя, Фамилия родителей человека % %:', name_param, surname_param;
    FOR result IN SELECT * FROM find_parents(name_param, surname_param) LOOP
        RAISE NOTICE '- % %', result.parent_name, result.parent_surname;
    END LOOP;
END;
$$;

alter function print_find_parents(varchar, varchar) owner to s368328;

